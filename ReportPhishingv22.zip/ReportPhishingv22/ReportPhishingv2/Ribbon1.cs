using Microsoft.Office.Core;
using Microsoft.Office.Tools.Ribbon;
using Microsoft.Win32;
using System;
using System.Globalization;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace ReportPhishingv2
{
    public partial class Ribbon1
    {
        public class PluginConfig
        {
            public string To { get; set; }
            public string Subject { get; set; }
            public string Body { get; set; }

            public bool IsValid
            {
                get
                {
                    // Sadece To zorunlu; Subject ve Body boş olabilir
                    return !string.IsNullOrWhiteSpace(To);
                }
            }
        }

        private static readonly PluginConfig Defaults = new PluginConfig
        {
            To = "oltalama@kkb.com.tr",
            Subject = "Oltalama Bildirimi",
            Body = "Lütfen ekteki e-postayı inceleyiniz."
        };
        private const string REG_KEY = @"Software\PhishingAddinforOutlook\PhishingReport";

        // ── Loglama ──────────────────────────────────────────────────────────
        private static readonly string LogPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "ReportPhishingv2", "ReportPhishing.log");

        private static void Log(string level, string message)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(LogPath));
                string line = string.Format("[{0:yyyy-MM-dd HH:mm:ss}] [{1}] {2}{3}",
                    DateTime.Now, level, message, Environment.NewLine);
                File.AppendAllText(LogPath, line, Encoding.UTF8);
            }
            catch { /* Loglama hatası uygulamayı durdurmamalı */ }
        }

        private static void LogInfo(string msg)  => Log("INFO ", msg);
        private static void LogWarn(string msg)  => Log("WARN ", msg);
        private static void LogError(string msg, Exception ex = null)
        {
            Log("ERROR", msg);
            if (ex != null)
            {
                Log("ERROR", "  Mesaj   : " + ex.Message);
                Log("ERROR", "  Tür     : " + ex.GetType().FullName);
                Log("ERROR", "  StackTrace: " + ex.StackTrace);
                if (ex.InnerException != null)
                    Log("ERROR", "  Inner   : " + ex.InnerException.Message);
            }
        }
        // ─────────────────────────────────────────────────────────────────────

        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {
            LogInfo("=== Add-in yüklendi ===");
            LogInfo("Log dosyası: " + LogPath);

            var languageCode = GetOfficeLanguageCode();
            LogInfo("Office dil kodu: " + languageCode);

            string groupLabel;
            string buttonLabel;

            switch (languageCode)
            {
                case "tr":
                    groupLabel = "Aksiyonlar";
                    buttonLabel = "Oltalama mail bildirimi";
                    break;
                case "en":
                    groupLabel = "Actions";
                    buttonLabel = "Phishing Mail Report";
                    break;
                case "de":
                    groupLabel = "Aktion";
                    buttonLabel = "Phishing-E-Mail-Benachrichtigung";
                    break;
                default:
                    groupLabel = "Actions";
                    buttonLabel = "Phishing Mail Report";
                    break;
            }
            this.group1.Label = groupLabel;
            this.button1.Label = buttonLabel;
            LogInfo("Ribbon etiketleri ayarlandı: Group=" + groupLabel + ", Button=" + buttonLabel);
        }

        private void button1_Click(object sender, RibbonControlEventArgs e)
        {
            LogInfo("--- Buton tıklandı ---");

            Outlook.Application app = (Globals.ThisAddIn != null) ? Globals.ThisAddIn.Application : null;
            if (app == null)
            {
                LogError("Outlook.Application nesnesi null");
                MessageBox.Show("Outlook Application henüz hazır değil.", "Uyarı");
                return;
            }
            LogInfo("Outlook.Application alındı");

            Outlook.Explorer explorer = null;
            Outlook.Selection selection = null;
            Outlook.Inspector inspector = null;
            Outlook.MailItem selectedMail = null;
            Outlook.MailItem mail = null;
            Outlook.Attachments attachments = null;
            Outlook.Attachment attachment = null;

            try
            {
                explorer = app.ActiveExplorer();
                selection = explorer != null ? explorer.Selection : null;
                LogInfo("Explorer selection sayısı: " + (selection != null ? selection.Count.ToString() : "null"));

                if (selection != null && selection.Count > 1)
                {
                    LogWarn("Birden fazla mail seçili, işlem iptal edildi");
                    MessageBox.Show("Lütfen yalnızca bir e-posta seçin.", "Uyarı");
                    return;
                }

                if (selection != null && selection.Count == 1 && selection[1] is Outlook.MailItem)
                {
                    selectedMail = (Outlook.MailItem)selection[1];
                    LogInfo("Mail Explorer'dan alındı. Subject: " + selectedMail.Subject);
                }
                else
                {
                    LogInfo("Explorer'da seçili mail yok, Inspector kontrol ediliyor...");
                    inspector = app.ActiveInspector();
                    if (inspector != null && inspector.CurrentItem is Outlook.MailItem)
                    {
                        selectedMail = (Outlook.MailItem)inspector.CurrentItem;
                        LogInfo("Mail Inspector'dan alındı. Subject: " + selectedMail.Subject);
                    }
                    else
                    {
                        LogWarn("Inspector'da da mail bulunamadı");
                    }
                }

                if (selectedMail == null)
                {
                    LogWarn("Seçili mail null, işlem iptal edildi");
                    MessageBox.Show("Lütfen bir e-posta seçin.", "Uyarı");
                    return;
                }

                LogInfo("İnternet bağlantısı kontrol ediliyor...");
                bool inet = IsInternetAvailable();
                LogInfo("İnternet durumu: " + inet);

                if (!inet)
                {
                    LogWarn("İnternet bağlantısı yok, işlem iptal edildi");
                    MessageBox.Show("İnternet bağlantısı bulunamadı. Lütfen bağlantınızı kontrol edin.", "Bağlantı Hatası");
                    return;
                }

                var confirmResult = MessageBox.Show(
                    "Seçili e-postayı Bilgi Güvenliği ekibine bildirmek istediğinize emin misiniz?\n\nBildirilen e-posta gelen kutunuzdan silinecektir.",
                    "Oltalama Bildirimi Onayı",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (confirmResult != DialogResult.Yes)
                {
                    LogInfo("Kullanıcı onaylamadı, işlem iptal edildi");
                    return;
                }
                LogInfo("Kullanıcı onayladı");

                PluginConfig config = LoadConfig();
                LogInfo("Config yüklendi -> To: " + config.To + " | Subject: " + config.Subject + " | Body uzunluğu: " + (config.Body ?? "").Length);

                if (string.IsNullOrWhiteSpace(config.To))
                {
                    LogError("Config.To boş! Mail gönderilemez.");
                    MessageBox.Show("Hedef e-posta adresi tanımlı değil. Lütfen Registry ayarlarını kontrol edin.", "Hata");
                    return;
                }

                string tempPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N") + ".msg");
                LogInfo("Geçici dosya yolu: " + tempPath);

                try
                {
                    LogInfo("Mail .msg olarak kaydediliyor...");
                    selectedMail.SaveAs(tempPath, Outlook.OlSaveAsType.olMSG);
                    LogInfo("SaveAs tamamlandı");

                    mail = app.CreateItem(Outlook.OlItemType.olMailItem) as Outlook.MailItem;
                    mail.To = config.To.Trim();
                    mail.Subject = config.Subject ?? "";
                    mail.Body = BuildBody(config.Body, selectedMail);
                    LogInfo("Yeni mail oluşturuldu. To: " + mail.To + " | Subject: " + mail.Subject);

                    // On-prem Exchange: alıcıyı adres defterinde doğrula
                    bool resolved = mail.Recipients.ResolveAll();
                    LogInfo("Recipients.ResolveAll() sonucu: " + resolved);
                    if (!resolved)
                        LogWarn("Alıcı Exchange adres defterinde çözümlenemedi, SMTP adresiyle devam ediliyor");

                    string attachName = SafeSubject(selectedMail.Subject) + ".msg";
                    attachments = mail.Attachments;
                    attachment = attachments.Add(tempPath, Outlook.OlAttachmentType.olByValue, 1, attachName);
                    LogInfo("Ek eklendi: " + attachName);

                    LogInfo("mail.Send() çağrılıyor...");
                    mail.Send();
                    LogInfo("mail.Send() başarıyla tamamlandı");

                    selectedMail.Delete();
                    LogInfo("Orijinal mail silindi");

                    MessageBox.Show(
                        "Bildirdiğiniz e-posta incelenmek üzere Bilgi Güvenliği ekiplerine iletilmiştir.",
                        "Başarılı");
                    LogInfo("İşlem başarıyla tamamlandı");
                }
                finally
                {
                    try { File.Delete(tempPath); } catch { }
                }
            }
            catch (Exception ex)
            {
                LogError("button1_Click içinde hata", ex);
                MessageBox.Show("İşlem sırasında bir hata oluştu: " + ex.Message, "Hata");
            }
            finally
            {
                if (attachment != null) Marshal.ReleaseComObject(attachment);
                if (attachments != null) Marshal.ReleaseComObject(attachments);
                if (mail != null) Marshal.ReleaseComObject(mail);
                if (selectedMail != null) Marshal.ReleaseComObject(selectedMail);
                if (inspector != null) Marshal.ReleaseComObject(inspector);
                if (selection != null) Marshal.ReleaseComObject(selection);
                if (explorer != null) Marshal.ReleaseComObject(explorer);
                LogInfo("COM nesneleri serbest bırakıldı");
            }
        }

        private PluginConfig LoadConfig()
        {
            LogInfo("LoadConfig: HKCU deneniyor...");
            PluginConfig cfg = ReadFromRegistry(RegistryHive.CurrentUser, RegistryView.Default);
            if (cfg.IsValid) { LogInfo("LoadConfig: HKCU'dan alındı -> To: " + cfg.To); return cfg; }

            LogInfo("LoadConfig: HKLM 64-bit deneniyor...");
            cfg = ReadFromRegistry(RegistryHive.LocalMachine, RegistryView.Registry64);
            if (cfg.IsValid) { LogInfo("LoadConfig: HKLM 64-bit'ten alındı -> To: " + cfg.To); return cfg; }

            LogInfo("LoadConfig: HKLM 32-bit deneniyor...");
            cfg = ReadFromRegistry(RegistryHive.LocalMachine, RegistryView.Registry32);
            if (cfg.IsValid) { LogInfo("LoadConfig: HKLM 32-bit'ten alındı -> To: " + cfg.To); return cfg; }

            LogWarn("LoadConfig: Registry'de geçerli config bulunamadı, default değerler kullanılıyor");
            return new PluginConfig
            {
                To = Defaults.To,
                Subject = Defaults.Subject,
                Body = Defaults.Body
            };
        }

        private PluginConfig ReadFromRegistry(RegistryHive hive, RegistryView view)
        {
            try
            {
                using (RegistryKey baseKey = RegistryKey.OpenBaseKey(hive, view))
                using (RegistryKey key = baseKey.OpenSubKey(REG_KEY))
                {
                    if (key == null)
                    {
                        LogInfo("  Registry key bulunamadı: " + hive + "\\" + REG_KEY);
                        return new PluginConfig();
                    }

                    var result = new PluginConfig
                    {
                        To      = ((key.GetValue("To")      as string) ?? "").Trim().Trim('"'),
                        Subject = ((key.GetValue("Subject") as string) ?? "").Trim().Trim('"'),
                        Body    = ((key.GetValue("Body")    as string) ?? "").Trim().Trim('"')
                    };
                    LogInfo("  Registry okundu: To='" + result.To + "' Subject='" + result.Subject + "' Body uzunluğu=" + result.Body.Length + " IsValid=" + result.IsValid);
                    return result;
                }
            }
            catch (Exception ex)
            {
                LogError("Registry okuma hatası (" + hive + ")", ex);
                return new PluginConfig();
            }
        }

        private string BuildBody(string baseBody, Outlook.MailItem source)
        {
            StringBuilder sb = new StringBuilder();

            if (!string.IsNullOrWhiteSpace(baseBody))
                sb.AppendLine(baseBody.Trim());

            string messageId = GetInternetMessageId(source);
            LogInfo("Message-ID: " + messageId);
            if (!string.IsNullOrWhiteSpace(messageId))
            {
                sb.AppendLine();
                sb.AppendLine("Message-ID: " + messageId);
            }

            sb.AppendLine();
            sb.AppendLine(GetTimestampFooter());
            return sb.ToString();
        }

        private string SafeSubject(string subject)
        {
            if (string.IsNullOrEmpty(subject)) return "Mail(Isimsiz)";
            char[] invalid = Path.GetInvalidFileNameChars();
            for (int i = 0; i < invalid.Length; i++)
                subject = subject.Replace(invalid[i].ToString(), "_");
            if (subject.Length > 200)
                subject = subject.Substring(0, 200);
            return subject;
        }

        private string GetTimestampFooter()
        {
            return string.Format("---{0}Gönderim Zamanı: {1:dd.MM.yyyy HH:mm:ss}",
                                 Environment.NewLine,
                                 DateTime.Now);
        }

        private string GetInternetMessageId(Outlook.MailItem mail)
        {
            const string PR_INTERNET_MESSAGE_ID = "http://schemas.microsoft.com/mapi/proptag/0x1035001F";
            Outlook.PropertyAccessor accessor = null;
            try
            {
                accessor = mail.PropertyAccessor;
                object val = accessor.GetProperty(PR_INTERNET_MESSAGE_ID);
                string messageId = val as string;
                return messageId ?? "(Message-ID bulunamadı)";
            }
            catch (Exception ex)
            {
                LogWarn("Message-ID okunamadı: " + ex.Message);
                return "(Message-ID okunamadı: " + ex.Message + ")";
            }
            finally
            {
                if (accessor != null) Marshal.ReleaseComObject(accessor);
            }
        }

        private bool IsInternetAvailable()
        {
            if (!NetworkInterface.GetIsNetworkAvailable())
            {
                LogWarn("IsInternetAvailable: Ağ arayüzü bağlı değil");
                return false;
            }
            LogInfo("IsInternetAvailable: Ağ arayüzü bağlı, DNS kontrol ediliyor...");

            try
            {
                System.Net.Dns.GetHostEntry("smtp.office365.com");
                LogInfo("IsInternetAvailable: smtp.office365.com DNS çözümlendi -> true");
                return true;
            }
            catch (Exception ex)
            {
                LogWarn("IsInternetAvailable: smtp.office365.com DNS hatası: " + ex.Message);
            }

            try
            {
                System.Net.Dns.GetHostEntry("dns.google");
                LogInfo("IsInternetAvailable: dns.google DNS çözümlendi -> true");
                return true;
            }
            catch (Exception ex)
            {
                LogWarn("IsInternetAvailable: dns.google DNS hatası: " + ex.Message);
            }

            LogWarn("IsInternetAvailable: Tüm DNS kontrolleri başarısız -> false");
            return false;
        }

        private string GetOfficeLanguageCode()
        {
            try
            {
                int langId = Globals.ThisAddIn.Application.LanguageSettings.get_LanguageID(MsoAppLanguageID.msoLanguageIDUI);
                CultureInfo culture = new CultureInfo(langId);
                return culture.TwoLetterISOLanguageName;
            }
            catch (Exception)
            {
                return "en";
            }
        }
    }
}
